# ClinicalMate (Omarchy theme)

A deep navy, teal and gold theme built around the ClinicalMate® brand identity.

## Install

```
omarchy theme install https://github.com/YOUR-USERNAME/omarchy-clinicalmate-theme.git
```

Or manually:

```
cp -r omarchy-clinicalmate-theme ~/.config/omarchy/themes/clinicalmate
omarchy theme set clinicalmate
```

## Contents

- `colors.toml` — palette (navy background, teal accents, gold highlight)
- `backgrounds/` — 6 wallpapers (1080x2400 portrait): Dawn Lake, Golden Sunset, Moonlit Night, Aurora, Misty Morning, Royal Enamel
- `preview.png`, `preview-unlock.png`, `unlock.png` — previews and lock screen image
- `screenshots/` — README screenshots

## Credits and license

Palette and configuration: MIT.
ClinicalMate® name, logo and artwork: © Dr. Mutaz Mustafa Ahmed Mohamed Khair. All rights reserved.
